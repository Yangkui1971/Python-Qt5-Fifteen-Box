# conding=utf-8
from PyQt5.QtWidgets import QWidget, QApplication, QMessageBox
import numpy as np
import random
import FifteenBoxWindow as Fif
import sys


# BOXSIZEROW = 4
# BOXSIZECOL = 4
class FifteenBoxGame(Fif.FifteenBoxWindow):
    def __init__(self):
        super().__init__()
        self.box = np.empty([self.BOXSIZEROW, self.BOXSIZECOL], dtype=np.int8)
        self.shuffle2()
        for i in range(self.BOXSIZEROW * self.BOXSIZECOL):
            self.pushButtonCollection[i].clicked.connect(self.cardButtonclicked)
        self.shuffleBtn.clicked.connect(self.shuffleBtnclicked)
        self.finishBtn.clicked.connect(self.finishBtnclicked)

    def fillarray(self, x: int) -> object:  # 用x填充数组
        for i in range(0, self.BOXSIZEROW):
            for j in range(self.BOXSIZECOL):
                self.box[i, j] = x

    def shuffle2(self):  # 洗牌, 利用random.shuffle函数
        self.clickNum = 0
        self.lcdNumber.display(self.clickNum)
        cardList = [x for x in range(0, self.BOXSIZECOL * self.BOXSIZEROW)]
        random.shuffle(cardList)
        for i in range(0, self.BOXSIZEROW):
            for j in range(0, self.BOXSIZECOL):
                x = cardList[self.BOXSIZECOL * i + j]
                self.box[i, j] = x
                if x != 0:
                    self.pushButtonCollection[self.BOXSIZECOL * i + j].setText(str(x))
                else:
                    self.pushButtonCollection[self.BOXSIZECOL * i + j].setText('')

    def shuffle(self):  # 洗牌，自编洗牌
        self.clickNum = 0
        self.lcdNumber.display(self.clickNum)
        self.fillarray(-1)  # 使用-1填充，0表示空位
        for i in range(0, self.BOXSIZEROW):
            for j in range(0, self.BOXSIZECOL):
                while (x := random.randint(0, self.BOXSIZEROW * self.BOXSIZECOL - 1)) in self.box:
                    pass
                else:
                    self.box[i, j] = x
                    if x != 0:
                        self.pushButtonCollection[self.BOXSIZECOL * i + j].setText(str(x))
                    else:
                        self.pushButtonCollection[self.BOXSIZECOL * i + j].setText('')

    def changeBtnTextFromArray(self, locY, locX):
        if self.box[locY, locX] != 0:
            self.pushButtonCollection[self.BOXSIZECOL * locY + locX].setText(str(self.box[locY, locX]))
        else:
            self.pushButtonCollection[self.BOXSIZECOL * locY + locX].setText('')

    def clickCount(self):
        self.clickNum += 1
        self.lcdNumber.display(self.clickNum)

    def isSuccessful(self) -> bool:
        for i in range(0, self.BOXSIZEROW):
            for j in range(0, self.BOXSIZECOL):
                if i == self.BOXSIZEROW - 1 and j == self.BOXSIZECOL - 1:
                    pass
                elif self.box[i, j] != i * self.BOXSIZECOL + j + 1:
                    return False
        return True

    def move(self, locY, locX):  # 看光标处是否可以移动
        if locX > 0 and self.box[locY, locX - 1] == 0:
            self.clickCount()
            self.box[locY, locX - 1] = self.box[locY, locX]
            self.box[locY, locX] = 0
            self.changeBtnTextFromArray(locY, locX)
            self.changeBtnTextFromArray(locY, locX - 1)
        elif locX < self.BOXSIZECOL - 1 and self.box[locY, locX + 1] == 0:
            self.clickCount()
            self.box[locY, locX + 1] = self.box[locY, locX]
            self.box[locY, locX] = 0
            self.changeBtnTextFromArray(locY, locX)
            self.changeBtnTextFromArray(locY, locX + 1)
        elif locY > 0 and self.box[locY - 1, locX] == 0:
            self.clickCount()
            self.box[locY - 1, locX] = self.box[locY, locX]
            self.box[locY, locX] = 0
            self.changeBtnTextFromArray(locY, locX)
            self.changeBtnTextFromArray(locY - 1, locX)
        elif locY < self.BOXSIZEROW - 1 and self.box[locY + 1, locX] == 0:
            self.clickCount()
            self.box[locY + 1, locX] = self.box[locY, locX]
            self.box[locY, locX] = 0
            self.changeBtnTextFromArray(locY, locX)
            self.changeBtnTextFromArray(locY + 1, locX)
            # other case, no space to move or it is space
        if self.isSuccessful():
            reply = QMessageBox.question(self, '询问', '祝贺，你成功了，要洗牌重玩吗？', QMessageBox.Yes | QMessageBox.No,
                                         QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.shuffle()

    def cardButtonclicked(self):
        sender = self.sender()
        locY = sender.yLoc
        locX = sender.xLoc
        self.move(locY, locX)

    def shuffleBtnclicked(self):
        reply = QMessageBox.question(self, '询问', '要洗牌重玩吗？', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.shuffle()

    def finishBtnclicked(self):
        reply = QMessageBox.question(self, '询问', '要退出吗？', QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if reply == QMessageBox.Yes:
            self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = FifteenBoxGame()
    ex.show()
    sys.exit(app.exec_())
