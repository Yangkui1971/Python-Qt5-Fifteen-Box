from PyQt5.QtWidgets import QWidget, QApplication, QPushButton

class MPushBtn(QPushButton):
    def __init__(self, mWindows):
        super().__init__(mWindows)
        self.xLoc=0
        self.yLoc=0
