#conding=utf-8

from PyQt5.QtWidgets import QWidget, QApplication, QPushButton, QMessageBox, QLabel
from PyQt5.QtGui import QPixmap
from PyQt5 import QtCore, QtGui, QtWidgets
import MPushBtnClass
import sys

# BOXSIZEROW = 4
# BOXSIZECOL = 4
# SINGLESIZE=200
# FONTSIZEBIG=48
# FONTSIZENORMAL=12

class FifteenBoxWindow(QWidget):
    BOXSIZEROW = 4
    BOXSIZECOL = 4
    SINGLESIZE=200
    FONTSIZEBIG=48
    FONTSIZENORMAL=12

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setObjectName("FifteenBoxGame")
        # Form.setWindowModality(QtCore.Qt.ApplicationModal)
        self.setWindowTitle("15子移位游戏")

        formSizeX=self.SINGLESIZE*self.BOXSIZECOL
        formSizeY=self.SINGLESIZE*self.BOXSIZEROW+50+60+50+50+50
        LCDY=self.SINGLESIZE*self.BOXSIZEROW+50
        BtnY=LCDY+60+50
        self.resize(formSizeX, formSizeY)
        self.setMinimumSize(QtCore.QSize(formSizeX, formSizeY))
        self.setMaximumSize(QtCore.QSize(formSizeX, formSizeY))

        fontBig = QtGui.QFont()
        fontBig.setFamily('Arial')
        fontBig.setPointSize(self.FONTSIZEBIG)

        fontNormal = QtGui.QFont()
        fontNormal.setFamily('Arial')
        fontNormal.setPointSize(self.FONTSIZENORMAL)

        quarterLocX=int(self.BOXSIZECOL*self.SINGLESIZE/4)
        # Shuffle button
        self.shuffleBtn = MPushBtnClass.QPushButton(self)
        self.shuffleBtn.setGeometry(QtCore.QRect(quarterLocX-int(200/2), BtnY, 200, 50))
        self.shuffleBtn.setObjectName("ShuffleButton")
        self.shuffleBtn.setText('-重新开始-')
        self.shuffleBtn.setMinimumSize(QtCore.QSize(200, 50))
        self.shuffleBtn.setMaximumSize(QtCore.QSize(200, 50))
        self.shuffleBtn.setFont(fontNormal)

        # Finish button
        self.finishBtn = QtWidgets.QPushButton(self)
        self.finishBtn.setGeometry(QtCore.QRect(self.BOXSIZECOL*self.SINGLESIZE-quarterLocX-int(150/2), BtnY, 150, 50))
        self.finishBtn.setObjectName("FinishButton")
        self.finishBtn.setText('-结束-')
        self.finishBtn.setMinimumSize(QtCore.QSize(150, 50))
        self.finishBtn.setMaximumSize(QtCore.QSize(150, 50))
        self.finishBtn.setFont(fontNormal)

        # Times LCD
        self.lcdNumber = QtWidgets.QLCDNumber(self)
        self.lcdNumber.setGeometry(QtCore.QRect(380, LCDY, 180, 60))
        self.lcdNumber.setObjectName("TimeLCDNumber")

        # TImes Lable
        self.label = QtWidgets.QLabel(self)
        self.label.setGeometry(QtCore.QRect(210, LCDY, 150, 50))
        self.label.setObjectName("TimesLabel")
        self.label.setText('Times:')
        self.label.setFont(fontNormal)

        self.pushButtonCollection=[]
        for i in range(0,self.BOXSIZEROW):
            for j in range(0,self.BOXSIZECOL):
                xPushButton = MPushBtnClass.MPushBtn(self)
                xPushButton.xLoc=j
                xPushButton.yLoc=i
                xPushButton.setEnabled(True)
                xPushButton.setGeometry(QtCore.QRect(self.SINGLESIZE*j, self.SINGLESIZE*i, self.SINGLESIZE, self.SINGLESIZE))
                xPushButton.setFont(fontBig)
                xPushButton.setCheckable(False)
                xPushButton.setChecked(False)
                xPushButton.setAutoDefault(False)
                xPushButton.setDefault(True)
                xPushButton.setObjectName("pushButton"+str(i)+str(j))
                xPushButton.setText(str(i*self.BOXSIZEROW+j+1))
                xPushButton.setCursor(QtGui.QCursor(QtCore.Qt.ClosedHandCursor))
                #xPushButton.clicked.connect(self.buttonclicked)
                self.pushButtonCollection.append(xPushButton) 
  
            
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = FifteenBoxWindow()
    ex.show()
    sys.exit(app.exec_()) 